package com.example.myassistant

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class SendAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: SendAccessibilityService? = null
    }

    @Volatile
    private var waitingUntil = 0L
    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    /** WhatsApp mein chat kholta hai, message pehle se likha hua. Send button baad mein dabta hai. */
    fun sendWhatsApp(number: String, text: String) {
        waitingUntil = System.currentTimeMillis() + 15000
        handler.post {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$number?text=${Uri.encode(text)}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            i.setPackage("com.whatsapp")
            try {
                startActivity(i)
            } catch (e: Exception) {
                try {
                    i.setPackage("com.whatsapp.w4b")
                    startActivity(i)
                } catch (e2: Exception) {
                    waitingUntil = 0
                }
            }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (System.currentTimeMillis() > waitingUntil) return
        val root = rootInActiveWindow ?: return
        if (findSend(root) == null) return
        waitingUntil = 0
        handler.postDelayed({
            rootInActiveWindow?.let { r -> findSend(r)?.let { click(it) } }
            handler.postDelayed({ performGlobalAction(GLOBAL_ACTION_HOME) }, 1500)
        }, 600)
    }

    private fun findSend(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        for (id in listOf("com.whatsapp:id/send", "com.whatsapp.w4b:id/send")) {
            root.findAccessibilityNodeInfosByViewId(id)?.firstOrNull()?.let { return it }
        }
        return searchByDescription(root)
    }

    private fun searchByDescription(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        val d = node.contentDescription?.toString()?.trim()?.lowercase()
        if (d == "send" || d == "भेजें") return node
        for (i in 0 until node.childCount) {
            searchByDescription(node.getChild(i))?.let { return it }
        }
        return null
    }

    private fun click(node: AccessibilityNodeInfo) {
        var n: AccessibilityNodeInfo? = node
        while (n != null && !n.isClickable) n = n.parent
        n?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }
}

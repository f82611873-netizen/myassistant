package com.example.myassistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private fun neededPermissions(): Array<String> {
        val l = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS)
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        return l.toTypedArray()
    }

    private fun startAssistant() {
        val i = Intent(this, AssistantService::class.java)
        startForegroundService(i)
        Toast.makeText(this, "Assistant chalu. 'Alexa' bolke try karo.", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("prefs", MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }

        root.addView(TextView(this).apply {
            text = "My Assistant"
            textSize = 24f
        })
        root.addView(TextView(this).apply {
            text = "1) API key daalo  2) Accessibility chalu karo  3) Start dabao.\n" +
                "Phir bolo: \"Alexa, Ali ko WhatsApp par bolo ki main kal aa raha hoon\""
            setPadding(0, 24, 0, 24)
        })

        val keyBox = EditText(this).apply {
            hint = "Claude API key (sk-ant-...)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("api_key", ""))
        }
        root.addView(keyBox)

        root.addView(Button(this).apply {
            text = "Key save karo"
            setOnClickListener {
                prefs.edit().putString("api_key", keyBox.text.toString().trim()).apply()
                Toast.makeText(this@MainActivity, "Save ho gaya", Toast.LENGTH_SHORT).show()
            }
        })

        root.addView(Button(this).apply {
            text = "Accessibility settings kholo"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        root.addView(Button(this).apply {
            text = "START assistant"
            setOnClickListener {
                val missing = neededPermissions().filter {
                    checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
                }
                if (missing.isEmpty()) startAssistant()
                else requestPermissions(missing.toTypedArray(), 1)
            }
        })

        root.addView(Button(this).apply {
            text = "STOP assistant"
            setOnClickListener { stopService(Intent(this@MainActivity, AssistantService::class.java)) }
        })

        setContentView(root)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startAssistant()
        }
    }
}

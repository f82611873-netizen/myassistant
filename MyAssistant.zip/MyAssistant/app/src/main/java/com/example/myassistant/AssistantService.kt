package com.example.myassistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.ContactsContract
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class AssistantService : Service(), TextToSpeech.OnInitListener {

    // Apne desh ka country code (India = 91). 10 digit number ke aage lagta hai.
    private val defaultCountryCode = "91"

    // Bolne wale naam jin par assistant jaagta hai
    private val wakeWords = listOf("alexa", "एलेक्सा", "अलेक्सा", "अलेक्स")

    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    @Volatile
    private var running = false

    private val systemPrompt = """
        Tum ek voice assistant ho. User ka bola hua command JSON mein badlo.
        Sirf JSON do, aur kuch nahi.
        Agar user kisi ko WhatsApp message bhejna chahta hai:
        {"app":"whatsapp","contact":"<sirf naam>","message":"<message user ki taraf se, usi bhasha mein jisme user ne bola>"}
        Agar command message bhejne ka nahi hai:
        {"app":"none","reply":"<chhota jawab>"}
    """.trimIndent()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val channelId = "assistant"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(channelId, "Assistant", NotificationManager.IMPORTANCE_LOW)
        )
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("My Assistant sun raha hai")
            .setContentText("'Alexa' bolke command do")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, notification)
        }

        if (!running) {
            running = true
            tts = TextToSpeech(this, this)
            main.post { startListening() }
        }
        return START_STICKY
    }

    override fun onInit(status: Int) {
        tts?.language = Locale("hi", "IN")
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u")
    }

    private fun startListening() {
        if (!running) return
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onError(error: Int) {
                val delay = if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500L else 400L
                main.postDelayed({ startListening() }, delay)
            }

            override fun onResults(results: Bundle?) {
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                process(text)
                main.postDelayed({ startListening() }, 400)
            }
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        recognizer?.startListening(intent)
    }

    private fun process(text: String) {
        val lower = text.lowercase()
        val w = wakeWords.firstOrNull { lower.contains(it) } ?: return
        val command = lower.substringAfter(w).trim().trimStart(',', '.', ' ')
        if (command.length < 3) {
            speak("Haan, boliye")
            return
        }
        Thread { handleCommand(command) }.start()
    }

    private fun handleCommand(command: String) {
        try {
            val key = getSharedPreferences("prefs", MODE_PRIVATE).getString("api_key", "").orEmpty()
            if (key.isBlank()) {
                speak("Pehle app mein API key daalo")
                return
            }
            val result = askClaude(key, command)
            if (result.optString("app") == "whatsapp") {
                val contact = result.optString("contact")
                val message = result.optString("message")
                val number = findNumber(contact)
                if (number == null) {
                    speak("$contact ka number contacts mein nahi mila")
                    return
                }
                val acc = SendAccessibilityService.instance
                if (acc == null) {
                    speak("Accessibility service chalu karo")
                    return
                }
                acc.sendWhatsApp(number, message)
                speak("$contact ko message bhej raha hoon")
            } else {
                speak(result.optString("reply", "Samajh nahi aaya"))
            }
        } catch (e: Exception) {
            speak("Kuch gadbad ho gayi")
        }
    }

    private fun askClaude(key: String, command: String): JSONObject {
        val body = JSONObject()
            .put("model", "claude-haiku-5-5")
            .put("max_tokens", 300)
            .put("system", systemPrompt)
            .put(
                "messages",
                JSONArray().put(JSONObject().put("role", "user").put("content", command))
            )
        val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("x-api-key", key)
        conn.setRequestProperty("anthropic-version", "2023-06-01")
        conn.doOutput = true
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
        val resp = stream.bufferedReader().readText()
        val text = JSONObject(resp).getJSONArray("content").getJSONObject(0).getString("text")
        return JSONObject(text.substring(text.indexOf('{'), text.lastIndexOf('}') + 1))
    }

    private fun findNumber(name: String): String? {
        if (name.isBlank()) return null
        val cursor = contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"),
            null
        ) ?: return null
        cursor.use {
            if (!it.moveToFirst()) return null
            var n = it.getString(0).filter { c -> c.isDigit() }
            if (n.startsWith("0")) n = n.trimStart('0')
            if (n.length == 10) n = defaultCountryCode + n
            return n
        }
    }

    override fun onDestroy() {
        running = false
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
